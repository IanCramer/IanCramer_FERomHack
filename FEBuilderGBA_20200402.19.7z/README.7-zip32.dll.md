7-zip32.dll
===
7-zip32 is a dll to use 7z created by the common archiver project.
For details and source code please visit this site.
http://www.madobe.net/archiver/lib/7-zip32.html

License: LGPL 2.1


7-zip32.dll
===
7-zip32は、統合アーカイバプロジェクトで作られた7zを利用するためのdllです。
詳細や、ソースコードはこちらのサイトをご覧ください。
http://www.madobe.net/archiver/lib/7-zip32.html

License: LGPL 2.1

